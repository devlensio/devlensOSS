import { BackendRouteNode, CodeEdge, CodeNode, ProjectFingerprint, RouteNode } from "../types";
import { buildLookupMaps } from "./buildLookup";
import { detectCallEdges } from "./edges/callEdges";
import { detectEventEdges } from "./edges/eventEdges";
import { detectGuardEdges } from "./edges/guardEdges";
import { detectImportEdges } from "./edges/importEdges";
import { detectPropEdges } from "./edges/propEdges";
import { detectStateEdges } from "./edges/stateEdges";


export interface EdgeDetectionResult {
    edges: CodeEdge[];
    ghostNodes: CodeNode[];
}

export function detectEdges(
    nodes: CodeNode[],
    routeNodes: (RouteNode | BackendRouteNode)[],
    repoPath: string,
    fingerprint: ProjectFingerprint,
): EdgeDetectionResult {
    console.log(`Building lookup maps for edge detection for ${nodes.length} nodes...`);

    //building lookup maps
    const lookupMp = buildLookupMaps(nodes);
    console.log("Running edge detectors...");
    const callEdges = detectCallEdges(nodes, lookupMp);
    const importEdges = detectImportEdges(lookupMp, repoPath);
    const stateEdges = detectStateEdges(nodes, lookupMp);
    const propEdges = detectPropEdges(nodes, lookupMp, repoPath);

    const eventResults = detectEventEdges(lookupMp, repoPath);
    // GUARDS — middleware to route protection
    const guardEdges = detectGuardEdges(
        nodes,
        lookupMp,
        routeNodes,
        repoPath,
        fingerprint
    );
    console.log(`Running edge detectors...`);
    console.log(`  CALLS edges: ${callEdges.length}`);
    console.log(`  IMPORTS edges: ${importEdges.length}`);
    console.log(`  STATE edges: ${stateEdges.length}`);
    console.log(`  PROP edges: ${propEdges.length}`);
    console.log(`  EVENT edges: ${eventResults.edges.length}`);
    console.log(`  GUARD edges: ${guardEdges.length}`);
    console.log(`  Ghost nodes created: ${eventResults.ghostNodes.length}`);

    const allEdges: CodeEdge[] = [
        ...callEdges,
        ...importEdges,
        ...stateEdges,
        ...propEdges,
        ...eventResults.edges,
        ...guardEdges,
    ];

    console.log(`Total edges detected: ${allEdges.length}`);

    return {
        edges: allEdges,
        ghostNodes: eventResults.ghostNodes,            //Ghost nodes passed back — ghost nodes need to be added to the main node list before the graph is stored. We return them separately so the pipeline can handle them correctly.
    };

}