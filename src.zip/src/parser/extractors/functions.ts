import { SourceFile, SyntaxKind } from "ts-morph";
import { CodeNode } from "../../types";

function makeId(filePath: string, name: string): string {
  return `${filePath}::${name}`;
}

function extractParams(node: any): string[] {
  const params = node.getParameters ? node.getParameters() : [];
  return params.map((p: any) => p.getName());
}

function extractFunctionCalls(node: any): string[] {
  const calls = node.getDescendantsOfKind(SyntaxKind.CallExpression);
  const names: string[] = [];
  for (const call of calls) {
    const name = call.getExpression().getText();
    // Skip hooks, they are handled by hooks extractor
    if (name.startsWith("use")) continue;
    // Skip console calls, they are noise
    if (name.startsWith("console")) continue;
    names.push(name);
  }
  return [...new Set(names)];
}

function extractApiCalls(node: any): string[] {
  const calls = node.getDescendantsOfKind(SyntaxKind.CallExpression);
  const apiCalls: string[] = [];

  for (const call of calls) {
    const text = call.getText();
    const expr = call.getExpression().getText();

    // ─── fetch ────────────────────────────────────────────────────────────────
    if (expr === "fetch") {
      const args = call.getArguments();
      if (args.length > 0) apiCalls.push(`fetch(${args[0].getText()})`);
    }

    // ─── axios ────────────────────────────────────────────────────────────────
    if (
      expr === "axios.get" ||
      expr === "axios.post" ||
      expr === "axios.put" ||
      expr === "axios.delete" ||
      expr === "axios.patch" ||
      expr === "axios"
    ) {
      const args = call.getArguments();
      if (args.length > 0) apiCalls.push(`${expr}(${args[0].getText()})`);
    }

    // ─── React Query (useQuery, useMutation, useInfiniteQuery) ────────────────
    if (
      expr === "useQuery" ||
      expr === "useMutation" ||
      expr === "useInfiniteQuery" ||
      expr === "useSuspenseQuery"
    ) {
      const args = call.getArguments();
      if (args.length > 0) apiCalls.push(`${expr}(${args[0].getText()})`);
    }

    // ─── SWR ──────────────────────────────────────────────────────────────────
    if (expr === "useSWR" || expr === "useSWRMutation") {
      const args = call.getArguments();
      if (args.length > 0) apiCalls.push(`${expr}(${args[0].getText()})`);
    }
  }

  return [...new Set(apiCalls)];
}

function hasErrorHandling(node: any): boolean {
  const tryCatch = node.getDescendantsOfKind(SyntaxKind.TryStatement);
  return tryCatch.length > 0;
}

function extractThrowStatements(node: any): boolean {
  const throws = node.getDescendantsOfKind(SyntaxKind.ThrowStatement);
  return throws.length > 0;
}

export function extractFunctions(file: SourceFile): CodeNode[] {
  const nodes: CodeNode[] = [];
  const filePath = file.getFilePath();

  // ─── Function Declarations ─────────────────────────────────────────────────

  for (const fn of file.getFunctions()) {
    const name = fn.getName();
    if (!name) continue;

    // Skip React components (uppercase) - handled by components extractor
    if (/^[A-Z]/.test(name)) continue;

    // Skip hooks - handled by hooks extractor
    if (/^use[A-Z]/.test(name)) continue;

    const params = extractParams(fn);
    const calls = extractFunctionCalls(fn);
    const apiCalls = extractApiCalls(fn);
    const isAsync = fn.isAsync();
    const hasErrors = hasErrorHandling(fn);
    const throws = extractThrowStatements(fn);

    nodes.push({
      id: makeId(filePath, name),
      name,
      type: "FUNCTION",
      filePath,
      startLine: fn.getStartLineNumber(),
      endLine: fn.getEndLineNumber(),
      rawCode: fn.getText(),
      metadata: {
        params,
        calls,
        apiCalls,
        isAsync,
        hasErrorHandling: hasErrors,
        throws,
        lineCount: fn.getEndLineNumber() - fn.getStartLineNumber(),
      },
    });
  }

  // ─── Arrow Function Declarations ───────────────────────────────────────────

  for (const variable of file.getVariableDeclarations()) {
    const name = variable.getName();

    // Skip React components
    if (/^[A-Z]/.test(name)) continue;

    // Skip hooks
    if (/^use[A-Z]/.test(name)) continue;

    const initializer = variable.getInitializer();
    if (!initializer) continue;

    const isArrow = initializer.getKind() === SyntaxKind.ArrowFunction;
    if (!isArrow) continue;

    const params = extractParams(initializer);
    const calls = extractFunctionCalls(initializer);
    const apiCalls = extractApiCalls(initializer);
    const isAsync = initializer.getText().startsWith("async");
    const hasErrors = hasErrorHandling(initializer);
    const throws = extractThrowStatements(initializer);

    nodes.push({
      id: makeId(filePath, name),
      name,
      type: "FUNCTION",
      filePath,
      startLine: variable.getStartLineNumber(),
      endLine: variable.getEndLineNumber(),
      rawCode: variable.getText(),
      metadata: {
        params,
        calls,
        apiCalls,
        isAsync,
        hasErrorHandling: hasErrors,
        throws,
        lineCount: variable.getEndLineNumber() - variable.getStartLineNumber(),
      },
    });
  }

  return nodes;
}